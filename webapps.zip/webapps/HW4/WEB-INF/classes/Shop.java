import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class Shop extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        Enumeration<String> e = request.getParameterNames();
        HttpSession session = request.getSession();
        String type = request.getParameter("type");

        if (type != null && type.equals("remove")) {

            while (e.hasMoreElements()) {
                String paramName = (String) e.nextElement();
                String[] arr = request.getParameterValues(paramName);
                for (String l : arr) {
                    session.removeAttribute(paramName);
                }
            }
            out.println("Item removed successfully");
            out.println("<a href='Computer.html'>[Go to Computer page ]</a>");
            out.println("<a href='Music.html'>[Go to Music page ]</a>");
            out.println("<a href='Book.html'>[Go to Book page ]</a>");
            out.println("<a href='shop'>[Go to cart ]</a>");
            return;

        } else {

            while (e.hasMoreElements()) {
                String paramName = (String) e.nextElement();
                String[] arr = request.getParameterValues(paramName);
                for (String l : arr) {
                    session.setAttribute(paramName, l);
                }
            }
            out.println("Item added successfully....");
            out.println("<a href='Computer.html'>[Go to Computer page ]</a>");
            out.println("<a href='Music.html'>[Go to Music page ]</a>");
            out.println("<a href='Book.html'>[Go to Book page ]</a>");
            out.println("<a href='shop'>[Go to cart ]</a>");
        }

    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) // form dersign
            throws ServletException, java.io.IOException {
        response.setContentType("text/html");

        PrintWriter out = response.getWriter();

        out.println("View Cart");
        out.println("<br/>");
        out.println("<br/>");
        HttpSession session = request.getSession();
        Enumeration e = (Enumeration) (session.getAttributeNames());

        while (e.hasMoreElements()) {
            String s;
            if ((s = e.nextElement().toString()) != null) {
                out.println("<form method='post' action='shop'>");
                String a = session.getAttribute(s).toString();
                if(!a.equals("remove"))
                {
                out.println("<input type='checkbox' name='" + s + "' value='" + a + "' /> ");

                out.println("<label>" + a + "</label>");
                // out.println(session.getValue((String) s));
                }
                out.println("<br/>");
                out.println("<br/>");
                out.println("<br/>");
            }

        }
        out.println("<input type='hidden' name='type' value='remove'/>");
        out.println("<a href='Computer.html'>[Go to Computer page ]</a>");
        out.println("<a href='Music.html'>[Go to Music page ]</a>");
        out.println("<a href='Book.html'>[Go to Book page ]</a>");
        out.println("<input type='submit' value='Remove Item'/>");
        out.println("</form>");

    }

}