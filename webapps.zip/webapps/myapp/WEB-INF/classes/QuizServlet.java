import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpSession;
import java.io.PrintWriter;
import java.io.IOException;

public class QuizServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String qn = request.getParameter("qn");
		String uri = request.getRequestURI();
		
		HttpSession session = request.getSession();
		
		if (qn.equals("1"))
		{
			//question 1 is submitted, so read question 1
			//store it somewhere for later access
			//display Question 2
			String answer1 = request.getParameter("question");
			Cookie c1 = new Cookie("answer1", answer1);
			c1.setMaxAge(604800);
			response.addCookie(c1);
			
			session.setAttribute("answer1", answer1);
			
			out.println("<!doctype HTML>");
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Online Quiz</title>");
			out.println("</head>");
			out.println("<body>");
			out.println("<h1>Session ID: " + session.getId() + "</h1>");
			out.println("<h1>Question 2: An object could be ...</h1>");
			out.println("<form action='quiz/q2' method='get'>");
			out.println("<input type='radio' name='question' value='a' checked/> anything<br/>");
			out.println("<input type='radio' name='question' value='b' /> an algorithm<br/>");
			out.println("<input type='radio' name='question' value='c' /> a data container<br/>");
			out.println("<input type='radio' name='question' value='d' /> a program<br/>");
			out.println("<input type='hidden' name='qn' value='2' />");
			out.println("<input type='submit' value='SEND ANSWER'/>");
			out.println("</form>");
			out.println("</body>");
			out.println("</html>");

			out.close();
		} else if (qn.equals("2"))
		{
			//question 2 is submitted, so read question 2
			//store it somewhere for later access
			//display Question 3
			
			String answer2 = request.getParameter("question");
			Cookie c2 = new Cookie("answer2", answer2);
			c2.setMaxAge(604800);
			response.addCookie(c2);
			
			session.setAttribute("answer2", answer2);
			
			out.println("<!doctype HTML>");
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Online Quiz</title>");
			out.println("</head>");
			out.println("<body>");
			out.println("<h1>Session ID: " + session.getId() + "</h1>");
			out.println("<h1>Question 3: Choose the appropriate data type for this value: 5.5</h1>");
			out.println("<form action='quiz/q3' method='get'>");
			out.println("<input type='radio' name='question' value='a' checked/> int<br/>");
			out.println("<input type='radio' name='question' value='b' /> double<br/>");
			out.println("<input type='radio' name='question' value='c' /> boolean<br/>");
			out.println("<input type='radio' name='question' value='d' /> String<br/>");
			out.println("<input type='hidden' name='qn' value='3' />");
			out.println("<input type='submit' value='SEND ANSWER'/>");
			out.println("</form>");
			out.println("</body>");
			out.println("</html>");

			out.close();
		} else if (qn.equals("3"))
		{
			//question 3 is submitted, so read question 3
			//store it somewhere for later access
			//tell the user that the last question was submitted
			//create a link to display all the answers
			String answer3 = request.getParameter("question");
			Cookie c3 = new Cookie("answer3", answer3);
			c3.setMaxAge(604800);
			response.addCookie(c3);
			
			session.setAttribute("answer3", answer3);
			
			out.println("<!doctype HTML>");
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Online Quiz</title>");
			out.println("</head>");
			out.println("<body>");
			out.println("<h1>Session ID: " + session.getId() + "</h1>");
			out.println("<h1>You have completed the Quiz successfully.</h1>");
			out.println("<a href='quiz/results?qn=ans'>Click here to see your results</a>");
		 	out.println("</body>");
			out.println("</html>");
			
		} else if (qn.equals("ans")) {
			//read the cookies
			Cookie [] cookies = request.getCookies();
			
			out.println("<!doctype HTML>");
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Online Quiz</title>");
			out.println("</head>");
			out.println("<body>");
			out.println("<h1>Session ID: " + session.getId() + "</h1>");
			out.println("<h1>Here are your answers from Session</h1>");
			out.println("<UL>");
			out.println("<LI>Answer 1: " + session.getAttribute("answer1") + "</LI>");
			out.println("<LI>Answer 2: " + session.getAttribute("answer2") + "</LI>");
			out.println("<LI>Answer 3: " + session.getAttribute("answer3") + "</LI>");
			out.println("</UL>");
			
			out.println("<hr/>");
			
			out.println("<h1>Here are your answers from Cookie</h1>");
			out.println("<UL>");
			for (int i = 0; i < cookies.length; i++) {
				if (cookies[i].getName().equals("answer1")) {
					out.println("<LI>Answer 1: " + cookies[i].getValue() + "</LI>");
				} else if (cookies[i].getName().equals("answer2")) {
					out.println("<LI>Answer 2: " + cookies[i].getValue() + "</LI>");
				} else if (cookies[i].getName().equals("answer3")) {
					out.println("<LI>Answer 3: " + cookies[i].getValue() + "</LI>");
				}
			}
			out.println("</UL>");
			
			out.println("</body>");
			out.println("</html>");
		}
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		
	}
}