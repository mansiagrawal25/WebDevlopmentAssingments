import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.Enumeration;

public class HW1Servlet extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        doPost(request, response);
    }
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        Enumeration e = request.getHeaderNames();       // gets all headers information
     
        out.println("<H3>Following are the Headers coming from the Client<BR></H3>");
     
        out.println("<table border=2 bordercolor=brown>");
     
        out.println("<tr><th bgcolor=#85C1E9>Header Name</th><th bgcolor=#85C1E9>Header Value</th></tr>");
     
        while(e.hasMoreElements())
        {
          String name = (String) e.nextElement();
          String value = request.getHeader(name);       // gets each header information separately
          out.println("<tr><th>"+name + "</th><th>" + value + "</th></tr>");
        }
        out.println("</table>");			
        out.close();
    }
}