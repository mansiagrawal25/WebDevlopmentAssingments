import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Survey extends HttpServlet {
    //Service method
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Assignment</title>");
        out.println("</head>");
        out.println("<body>");
	 out.println("<form method ='post' action='Survey'>"); 
	 int y=Integer.parseInt(request.getParameter("childnumber"));
                for(int z=1;z<=y;z++)
				{  
	 out.println("<label>Please enter the name of child </label>"+z+"<input type='text' name='secondone'><br />");
	
				}
     out.println("<input type = 'submit' value = 'Next' name = 'searchs'/><br />");
	
    out.println("</form>");
	    out.println("</body>");
        out.println("</html>");
  
                  }		
		
    
    
	 public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
		 String[] childNames=request.getParameterValues("secondone");
         out.println("<html>");
        out.println("<head>");
        out.println("<title>Assignment</title>");
        out.println("</head>");
        out.println("<body>");
         
	 for(String l: childNames){
           out.println("Your child names is "+l +"<br/>");
		  
		   
       }
      
        out.println("</body>");
        out.println("</html>");
    }
}