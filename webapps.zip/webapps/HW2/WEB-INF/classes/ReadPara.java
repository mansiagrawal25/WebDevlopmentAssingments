import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.Enumeration;

public class ReadPara extends HttpServlet{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException{
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String title = "Read all Parameters";
        String docType =
           "<!doctype html public \"-//w3c//dtd html 4.0 " + "transitional//en\">\n";
           out.println(docType +
           "<html>\n" +
           "<head><title>" + title + "</title></head>\n" +
           "<body bgcolor = \"#f0f0f0\">\n" +
           "<h1 align = \"center\">" + title + "</h1>\n" +
           "<table width = \"100%\" border = \"1\" align = \"center\">\n" +
           "<tr bgcolor = \"#949494\">\n" 
        );
        Enumeration paramNames = request.getParameterNames();

      while(paramNames.hasMoreElements()) {
        String paramName = (String)paramNames.nextElement();
        out.print("<tr><td>" + paramName + "</td>\n<td>");
        String[] paramValues = request.getParameterValues(paramName);

        // Read single valued data
        if (paramValues.length == 1) {
           String paramValue = paramValues[0];
           if (paramValue.length() == 0)
              out.println("<i>No Value</i>");
              else
              out.println(paramValue);
        } else {
           // Read multiple valued data
           out.println("<ul>");

           for(int i = 0; i < paramValues.length; i++) {
              out.println("<li>" + paramValues[i]);
           }
           out.println("</ul>");
        }
     }
     out.println("</tr>\n</table>\n</body></html>");
     out.close(); 
  }
           
        // out.println(docType +
        //    "<html>\n" +
        //       "<head><title>" + title + "</title></head>\n" +
        //       "<body bgcolor = \"#f0f0f0\">\n" +
        //          "<h1 align = \"center\">" + title + "</h1>\n" +
        //          "<ul>\n" +
        //             "  <li><b>First Name</b>: "
        //             + request.getParameter("email") + "\n" +
        //             "  <li><b>Password</b>: "
        //             + request.getParameter("password") + "\n" +
        //             "  <li><b>picture</b>: "
        //             + request.getParameter("browse") + "\n" +
            
        //             "  <li><b>Gender</b>: "
        //             + request.getParameter( "gender" ) + "\n" +
        //             "  <li><b>Counrty</b>: "
        //             + request.getParameter("country") + "\n" +
        //             "  <li><b>Hobby</b>: "
        //             + request.getParameter("Hobby") + "\n" +
        //             "  <li><b>Address</b>: "
        //             + request.getParameter("address") + "\n" +

                   
        //          "</ul>\n" +
        //       "</body>" +
        //    "</html>"
        // );
			   
    

	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		// doGet(request, response);
	}
}