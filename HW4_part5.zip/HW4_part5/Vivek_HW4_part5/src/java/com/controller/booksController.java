/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.Dao.booksDAO;
import com.pojo.Books;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author mansiagrawal
 */
public class booksController extends AbstractController {
    
    public booksController() {
    }
    
    protected ModelAndView handleRequestInternal(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        
        booksDAO booksdao = (booksDAO) this.getApplicationContext().getBean("booksdao");
        HttpSession session = request.getSession(true);
        String action = request.getParameter("action");
        List<Books> bookList = new ArrayList<Books>();
        
        if(action.equals("add")){
            int num = Integer.parseInt(request.getParameter("number"))-1;
            session.setAttribute("number", num);
            return new ModelAndView("addbooks");
        }
        else if(action.equals("added")){
            //Books b = (Books) this.getApplicationContext().getBean("books");
            int j = Integer.parseInt(String.valueOf(session.getAttribute("number")));
            System.out.println("j = " +j);
            for(int i=0;i<=j;i++){ 
                Books b = new Books();
                String isbn = request.getParameter("isbn" + i);
                String title = request.getParameter("title" + i);
                String author = request.getParameter("author" + i);
                String price = request.getParameter("price" + i);
                b.setAuthor(author);
                b.setIsbn(isbn);
                b.setName(title);
                System.out.println(
                        "com.me.controller.BooksController.handleRequestInternal():"
                        + " price = " + price
                        + " isbn = " + isbn
                        + " author = " + author
                        + " title = " + title);
                
                b.setPrice(Double.parseDouble(price));
                System.out.println("Books here are as follows : " +b.getAuthor() + b.getIsbn() + b.getName());
                bookList.add(b);
                
            }
            booksdao.saveBooks(bookList);
            return new ModelAndView("successPage");
        }
        return null;
    }}

    

