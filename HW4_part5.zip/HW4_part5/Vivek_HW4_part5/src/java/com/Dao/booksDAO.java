/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Dao;

import com.pojo.Books;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author mansiagrawal
 */
public class booksDAO {
    Configuration cfg = new Configuration();
    SessionFactory sf = cfg.configure("hibernate.cfg.xml").buildSessionFactory();
    
    public void saveBooks(List<Books> books){
        
        
        Session session = sf.openSession();
        session.beginTransaction();
        
//        String hql = "INSERT INTO book VALUES (?,?,?,?);";
//        Query q =session.createSQLQuery(hql).addEntity(Books.class);
//        List result = q.list();
       for(Books bb:books){
           Books b = new Books();
           b.setIsbn(bb.getIsbn());
        b.setAuthor(bb.getAuthor());
        b.setName(bb.getName());
        b.setPrice(bb.getPrice());
        session.save(b);
       }
        //Books b = new Books();
        
//        emp.("lokesh@mail.com");
//        emp.setFirstName("lokesh");
//        emp.setLastName("gupta");

        
        
        session.getTransaction().commit();
        
        sf.close();
        session.close();
        //return b;
        
    }
}

