/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dao;

import com.vivek.pojo.movies;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author Dell
 */
public class movieDao {
    
    Configuration cfg = new Configuration();
    SessionFactory sf = cfg.configure("hibernate.cfg.xml").buildSessionFactory();
    
    public movies addMovies(movies movie){
        
        try (Session session = sf.openSession()) {
            session.beginTransaction();
            session.save(movie);
            session.getTransaction().commit();
        }
        sf.close();
        return movie;
    }
    public ArrayList<movies> getMovies(){
        
        
        Session session = sf.openSession();
        String hql = "Select * from movies";
        Query q;
        q = session.createSQLQuery(hql).addEntity(movies.class);
        List result = q.list();
        return (ArrayList<movies>) result;
        
        //return null;
    }
    
}





