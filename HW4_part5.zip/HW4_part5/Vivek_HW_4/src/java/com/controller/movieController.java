/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.vivek.dao.movieDao;
import com.vivek.pojo.movies;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author Dell
 */
public class movieController extends AbstractController {

    public movieController() {
    }

    protected ModelAndView handleRequestInternal(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {

        ModelAndView mav = null;
        ArrayList<movies> movieslist = new movieDao().getMovies();
        
        String action = request.getParameter("action");
        if (action.equals("add")) {

            if (request.getParameter("title") != null) {
                String movieTitle = request.getParameter("title");
                String leadActor = request.getParameter("actor");
                String leadActress = request.getParameter("actress");
                String genre = request.getParameter("genre");
                String year = request.getParameter("year");

                movies movie = new movies();
                movie.setGenre(genre);
                movie.setActor(leadActor);
                movie.setActress(leadActress);
                movie.setTitle(movieTitle);
                movie.setYear(year);

                movies result = new movieDao().addMovies(movie);
                String message = "movie added successfully";

                mav = new ModelAndView("addMovie", "msg", message);
            } else {
                mav = new ModelAndView("addMovie", "addmoviesResult", null);
            }
        } else if (action.equals("search")) {
            ArrayList<movies> searchResult = new ArrayList<movies>();
            String searchType = request.getParameter("searchType");
            System.out.println("search type"+ searchType);
            String searchQuery = request.getParameter("query");
             System.out.println("search query"+ searchQuery);
            if (searchType != null && searchQuery !=null) {
                if (searchType.equals("title")) {
                    for (movies mov : movieslist) {
                        System.out.println("Title" + mov.getTitle());
                        System.out.println("Search Query" + searchQuery);
                        if (mov.getTitle().contains(searchQuery)) {
                            searchResult.add(mov);
                            System.out.println("Movies" + mov);
                        }
                    }
                } else if (searchType.equals("actor")) {
                    for (movies mov : movieslist) {
                        if (mov.getActor().equals(searchQuery)) {
                            searchResult.add(mov);
                        }
                    }
                } else if (searchType.equals("actress")) {
                    for (movies mov : movieslist) {
                        if (mov.getActress().contains(searchQuery)) {
                            searchResult.add(mov);
                        }
                    }
                }
              mav = new ModelAndView("searchMovies","searchResults",searchResult);
            }else{
                mav = new ModelAndView("searchMovies","searchResults",null);
            }
        }

        return mav;
    }

}








